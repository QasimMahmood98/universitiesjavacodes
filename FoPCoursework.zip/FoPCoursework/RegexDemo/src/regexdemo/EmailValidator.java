/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package regexdemo;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author qmahmoo9
 */
public class EmailValidator {

    private final Pattern pattern;
    private Matcher matcher;

    private static final String EMAIL_PATTERN
            = "^[A-Za-z](.*)([@]{1})(.{1,})(\\.)(.{1,})";
//it all link to the email (.*) = anything except space or tab ([@]{1}) = only 1 @ (\\.) it means only 1 dot
    public static void main(String[] args) {
        EmailValidator ev = new EmailValidator();
        if (ev.validate("hassanadeyoola@gmail.com")) {
            System.out.println("It matches");
        }
    }

    public EmailValidator() {
        pattern = Pattern.compile(EMAIL_PATTERN);
    }

    public boolean validate(final String hex) {

        matcher = pattern.matcher(hex);
        return matcher.matches();
    }

}
