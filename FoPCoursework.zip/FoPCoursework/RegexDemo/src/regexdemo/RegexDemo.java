/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package regexdemo;
import java.util.Scanner;
import java.util.regex.*;
import java.util.regex.Pattern;

/**
 *
 * @author qmahmoo9
 */
public class RegexDemo {

    /**
     * @param args the command line arguments
     */
   // public static void main(String[] args) {
        //TODO code application logic here
        //string text to match
      //  String toMatch ="Fun";
         //the pattern i want to match against or validate
       // String pattern = "[A-Z][a-z][a-z]";
       // Pattern p = Pattern.compile(pattern);
       // if match is found, Print details of the match
      //  Matcher m = p.matcher(toMatch);
      //  if (m.matches()) //this makes sure its found
      //  System.out.println("match found");
      //  else// this makes sure its not there
      //  System.out.println("Match Not Found");
   // }
}
   // public static void main(String[] args) {
       // UK postcode Task 1
       // Scanner sc = new Scanner(System.in);
       // String pattern = "[A-Z]{1,2}[0-9]{1,2} [0-9]{1,2}[A-Z]{1,2}";
       // String Input = sc.nextLine();
     //  Pattern p = Pattern.compile(pattern);
      //  Matcher m = p.matcher(Input);
    //   if (m.matches())
    //   System.out.println("match found");
    //   else
    //   System.out.println("match not found");
        
        
  // }    
  // }

    //public static void main(String[] args) {
      //String s = "11,22,44,55,66";
       //String [] sp= s.split(",");
        //for (int i = 0; i<sp.length; i++){
          // System.out.println(sp[i]);
        //}


    
//}
