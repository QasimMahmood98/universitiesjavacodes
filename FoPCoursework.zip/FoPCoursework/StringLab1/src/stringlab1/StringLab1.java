/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stringlab1;

/**
 *
 * @author qmahmoo9
 */
public class StringLab1 {
    public static void main(String[] args) {
        // TODO code application logic here

    
   StringBuilder sb = new StringBuilder("Able was I ere I saw Elba.");

String hannah = "Was it a car or a cat I saw?";
String i = hannah.substring(9,12);
System.out.println(i);

}
           
}
