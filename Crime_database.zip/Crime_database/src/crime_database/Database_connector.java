/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package crime_database;

import static crime_database.GUIhandler.buildTableModel;
import java.sql.*;
import java.util.Vector;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author qmahmoo9
 */
public class Database_connector {

    private Connection con;
    private Statement st;
    private ResultSet rs;
    //public JTable table = null;

    public Database_connector() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://lamp.scim.brad.ac.uk:3306/qmahmoo9", "qmahmoo9", "Ip0dinit");
            st = con.createStatement();

        } catch (Exception ex) {
            System.out.println("Error:" + ex);
        }
    }

    public void getLongitudeTable(String search) {
        String[] names = {"Antisocial behvaiour", "Bugarly", "Voilence and other", "Theft from the person", "Drugs", "Robbery", "shoplifting", "vehicle crime", "possesion of weapon", "public"};
        try {

            String query = "select * from `crimedata` WHERE `Longitude` LIKE '%" + search + "%' LIMIT 25";
            rs = st.executeQuery(query);
            System.out.println("record from databse");
            DefaultTableModel model = new DefaultTableModel();
            model.setColumnIdentifiers(names);
            
            JTable table = new JTable(buildTableModel(rs));
JOptionPane.showMessageDialog(null, new JScrollPane(table));
            ///*nameofoptionpane*/.setPreferredSize(new Dimension(width, height));
            while (rs.next()) {
                String longitude = rs.getString("longitude");
                String latitude = rs.getString("latitude");
                String crimeID = rs.getString("crime ID");
                String Month = rs.getString("month");
                String Reportedby = rs.getString("Reported by");
                String FallsWithin = rs.getString("Falls Within");
                String Location = rs.getString("Location");
                String LSOACode = rs.getString("LSOA Code");
                String LSOAName = rs.getString("LSOA Name");
                String CrimeType = rs.getString("Crime Type");
                String Lastoutcomecategory = rs.getString("Last outcome category");
                String Context = rs.getString("Context");
                System.out.println("longitude" + longitude + "latitude" + latitude + "crimeID" + crimeID + "month" + Month + "Reportedby" + Reportedby + "FallsWithin" + FallsWithin + "Location" + Location + "LSOACode" + LSOACode + "LSOAName" + LSOAName + "CrimeType" + CrimeType);
            }
        } catch (Exception ex) {
            System.out.println(ex);
        }
    }
  public void getLatitudeTable(String search) {
        String[] names = {"Antisocial behvaiour", "Bugarly", "Voilence and other", "Theft from the person", "Drugs", "Robbery", "shoplifting", "vehicle crime", "possesion of weapon", "public"};
        try {

            String query = "select * from `crimedata` WHERE `Latitude` LIKE '%" + search + "%' LIMIT 25";
            rs = st.executeQuery(query);
            System.out.println("record from databse");
            DefaultTableModel model = new DefaultTableModel();
            model.setColumnIdentifiers(names);
                    
            JTable table = new JTable(buildTableModel(rs));
JOptionPane.showMessageDialog(null, new JScrollPane(table));
            
            while (rs.next()) {
                String longitude = rs.getString("longitude");
                String latitude = rs.getString("latitude");
                String crimeID = rs.getString("crime ID");
                String Month = rs.getString("month");
                String Reportedby = rs.getString("Reported by");
                String FallsWithin = rs.getString("Falls Within");
                String Location = rs.getString("Location");
                String LSOACode = rs.getString("LSOA Code");
                String LSOAName = rs.getString("LSOA Name");
                String CrimeType = rs.getString("Crime Type");
                String Lastoutcomecategory = rs.getString("Last outcome category");
                String Context = rs.getString("Context");
                System.out.println("longitude" + longitude + "latitude" + latitude + "crimeID" + crimeID + "month" + Month + "Reportedby" + Reportedby + "FallsWithin" + FallsWithin + "Location" + Location + "LSOACode" + LSOACode + "LSOAName" + LSOAName + "CrimeType" + CrimeType);
            }
        } catch (Exception ex) {
            System.out.println(ex);
        }
    }
    public void getLSOATable(String search) {
        String[] names = {"Antisocial behvaiour", "Bugarly", "Voilence and other", "Theft from the person", "Drugs", "Robbery", "shoplifting", "vehicle crime", "possesion of weapon", "public"};
        try {

            String query = "select * from `crimedata` WHERE `LSOA Name` LIKE '%" + search + "%' LIMIT 25";
            rs = st.executeQuery(query);
            System.out.println("record from databse");
            DefaultTableModel model = new DefaultTableModel();
            model.setColumnIdentifiers(names);
            
                    
            JTable table = new JTable(buildTableModel(rs));
JOptionPane.showMessageDialog(null, new JScrollPane(table));
            while (rs.next()) {
                String longitude = rs.getString("longitude");
                String latitude = rs.getString("latitude");
                String crimeID = rs.getString("crime ID");
                String Month = rs.getString("month");
                String Reportedby = rs.getString("Reported by");
                String FallsWithin = rs.getString("Falls Within");
                String Location = rs.getString("Location");
                String LSOACode = rs.getString("LSOA Code");
                String LSOAName = rs.getString("LSOA Name");
                String CrimeType = rs.getString("Crime Type");
                String Lastoutcomecategory = rs.getString("Last outcome category");
                String Context = rs.getString("Context");
                System.out.println("longitude" + longitude + "latitude" + latitude + "crimeID" + crimeID + "month" + Month + "Reportedby" + Reportedby + "FallsWithin" + FallsWithin + "Location" + Location + "LSOACode" + LSOACode + "LSOAName" + LSOAName + "CrimeType" + CrimeType);
            }
        } catch (Exception ex) {
            System.out.println(ex);
        }
    }
      public void getCrimeTypeTable(String search) {
        String[] names = {"Antisocial behvaiour", "Bugarly", "Voilence and other", "Theft from the person", "Drugs", "Robbery", "shoplifting", "vehicle crime", "possesion of weapon", "public"};
        try {

            String query = "select * from `crimedata` WHERE `Crime type` LIKE '%" + search + "%' LIMIT 25";
            rs = st.executeQuery(query);
            System.out.println("record from databse");
            DefaultTableModel model = new DefaultTableModel();
            model.setColumnIdentifiers(names);
            
                    
            JTable table = new JTable(buildTableModel(rs));
JOptionPane.showMessageDialog(null, new JScrollPane(table));
            while (rs.next()) {
                String longitude = rs.getString("longitude");
                String latitude = rs.getString("latitude");
                String crimeID = rs.getString("crime ID");
                String Month = rs.getString("month");
                String Reportedby = rs.getString("Reported by");
                String FallsWithin = rs.getString("Falls Within");
                String Location = rs.getString("Location");
                String LSOACode = rs.getString("LSOA Code");
                String LSOAName = rs.getString("LSOA Name");
                String CrimeType = rs.getString("Crime Type");
                String Lastoutcomecategory = rs.getString("Last outcome category");
                String Context = rs.getString("Context");
                System.out.println("longitude" + longitude + "latitude" + latitude + "crimeID" + crimeID + "month" + Month + "Reportedby" + Reportedby + "FallsWithin" + FallsWithin + "Location" + Location + "LSOACode" + LSOACode + "LSOAName" + LSOAName + "CrimeType" + CrimeType);
            }
        } catch (Exception ex) {
            System.out.println(ex);
        }
    }
    public void getData() {
        try {
            String query = "select * from crimedata LIMIT 100";
            rs = st.executeQuery(query);
            System.out.println("record from databse");
            //DefaultTableModel model = new DefaultTableModel();

            while (rs.next()) {
                // Object[] objectArray = new Object[rs.getMetaData().getColumnCount()];
                //for (int i =0; i< objectArray.length; i++){
                // objectArray[i] =rs.getObject(i + 1);
                // }
                // model.addRow(objectArray);

                String longitude = rs.getString("longitude");
                String latitude = rs.getString("latitude");
                String crimeID = rs.getString("crime ID");
                String Month = rs.getString("month");
                String Reportedby = rs.getString("Reported by");
                String FallsWithin = rs.getString("Falls Within");
                String Location = rs.getString("Location");
                String LSOACode = rs.getString("LSOA Code");
                String LSOAName = rs.getString("LSOA Name");
                String CrimeType = rs.getString("Crime Type");
                String Lastoutcomecategory = rs.getString("Last outcome category");
                String Context = rs.getString("Context");
                System.out.println("longitude:  " + longitude + "latitude:  " + latitude + "crimeID:    " + crimeID + "month:   " + Month + "Reportedby:    " + Reportedby + "FallsWithin:  " + FallsWithin + "Location:    " + Location + "LSOACode:   " + LSOACode + "LSOAName:   " + LSOAName + "CrimeType:  " + CrimeType);
            }
            //table = new JTable(model);
        } catch (Exception ex) {
            System.out.println(ex);
        }
    }

    private static class Reported {

        public Reported() {
        }
    }

    private static class LSOA {

        public LSOA() {
        }
    }

    private static class Falls {

        public Falls() {
        }
    }

    private static class outcome {

        public outcome() {
        }
    }
public static DefaultTableModel buildTableModel(ResultSet rs)
    throws SQLException {

ResultSetMetaData metaData = rs.getMetaData();

// names of columns
Vector<String> columnNames = new Vector<String>();
int columnCount = metaData.getColumnCount();
for (int column = 1; column <= columnCount; column++) {
    columnNames.add(metaData.getColumnName(column));
}
// data of the table
Vector<Vector<Object>> data = new Vector<Vector<Object>>();
while (rs.next()) {
    Vector<Object> vector = new Vector<Object>();
    for (int columnIndex = 1; columnIndex <= columnCount; columnIndex++) {
        vector.add(rs.getObject(columnIndex));
    }
    data.add(vector);
}

return new DefaultTableModel(data, columnNames);

}
}

