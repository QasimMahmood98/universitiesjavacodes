/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package crime_database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import static java.time.Clock.system;

/**
 *
 * @author qmahmoo9
 */
public class Crime_database {

    public static void main(String[] args) {

        try {
            String username = "qmahmoo9";
            String Password = "Ip0dinit";
            Class.forName("com.mysql.jdbc.Driver"); // Loading the MySQL JDBC Driver
            Connection con = DriverManager.getConnection(
                    "jdbc:mysql://lamp.scim.brad.ac.uk:3306/your-db", "username", "password");
        } catch (ClassNotFoundException | SQLException cnfe) {
        }
    }
}
