/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MiniProject;

/**
 * Driver for the LabClass.
 * 
 * @author Ian Bradley 
 * @version 14-03-2008
 */
public class LabClassDriver {
	public static void main(String[] args)
	{
		LabClassTextUI labClassTextUI = new LabClassTextUI();
		labClassTextUI.menu();
	}
}