/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package crimedatabase;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
/**
 *
 * @author qmahmoo9
 */
public class GUIHandler extends JFrame {
   public static void main(String[] args) {
      //create the window
      JFrame f = new JFrame("Crime Database");
      //quit Java after closing the window
      f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      f.setSize(1000, 1000); //set size in pixels
      f.setVisible(true); //show the window
   
    private JLabel jLabelLat;
    private JLabel jLabelLong;
    private JLabel jlabelLSOAnamne;
    private JLabel jlabelCrimetype;
    
    
    private JTextField jTextFieldlat;
    private JTextField jTextFieldlong;
    private JTextField jtextFieldLSOAname;
    private JTextField jTextFieldCrimetype;
    
     JLabel label= new JLabel();
     JLabel label2= new JLabel();
     JLabel label3= new JLabel();
     JLabel label4 = new JLabel();
   JTextField field1 = new JTextField ();
   JTextField field2 = new JTextField ();
   JTextField field3 = new JTextField ();
   JTextField field4 = new JTextField ();
   }
}
      
    
    
   
    
    






      
      
      
      
        

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
   public static void main(String[] args) {
      GUIHandler g = new GUIHandler ();
    public GUIHandler() {
        JFrame f = new JFrame("Crime Data Base");
      f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      f.setSize(1000, 1000); 
      f.setVisible(true); 
        
   }
}




