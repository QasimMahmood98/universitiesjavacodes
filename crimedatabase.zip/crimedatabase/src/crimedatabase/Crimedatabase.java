/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package crimedatabase;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author qmahmoo9
 */
public class Crimedatabase {
    
        try {
            String username = "qmahmoo9";
            String Password = "Ip0dinit";
            Class.forName ("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection(
                "jdbc:mysql://lamp.scim.brad.ac.uk:3306/qmahmoo9", "qmahmoo9", "Ip0dinit");
        } catch (SQLException se) {
            System.out.println(se.getMessage());
        } 
    }
    
}

//if statements
//loops
//get a code that writes it to the interface

