/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author qmahmoo9
 */
import java.sql.*;

public class crime_database {
    public static void main(String[] args) throws ClassNotFoundException {
        try {
            String username = "qmahmoo9";
            String Password = "Ip0dinit";
            Class.forName ("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection(
                "jdbc:mysql://lamp.scim.brad.ac.uk:3306/qmahmoo9", "qmahmoo9", "Ip0dinit");
        } catch (SQLException se) {
            System.out.println(se.getMessage());
        } 
    }
    
}
