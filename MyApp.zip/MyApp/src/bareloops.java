/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
 import java.util.Scanner;

/**
 *
 * @author qmahmoo9
 */
public class bareloops {
   
    public static void main (String args[]) {

	String input = "";
	int num = 0;
	int sum = 0;
	Scanner in = new Scanner(System.in);

	for (int i = 0; i < 10; i++) {
	    System.out.println("Please input a number");
	    input = in.nextLine();
	    num = Integer.parseInt(input);
	    sum += num;              //what does this operator do?
	}

	int average = sum/10;
	System.out.println("Average value is: " + average);
    }
}

