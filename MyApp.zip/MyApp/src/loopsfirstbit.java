/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.io.*;
import java.util.Scanner;
/**
 *
 * @author qmahmoo9
 */
public class loopsfirstbit {
   


    	public static void main (String[] args) throws IOException {
		Scanner stdin = new Scanner(System.in);
		String inData;
		int age;
		System.out.println("Enter your age:");
		inData = stdin.nextLine();
		age = Integer.parseInt( inData ); // convert inData to int
		if ( age < 17 ) {
			System.out.println("Child rate.");
		}
		else {
	    		System.out.println("Adult rate.");
		}
	System.out.println("Enjoy the"
                + " show."); // always executed
	}
}










