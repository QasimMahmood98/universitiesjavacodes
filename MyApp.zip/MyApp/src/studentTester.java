/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author qmahmoo9
 */
public class studentTester {
    public static void main(String args[]) {
		student x = new student("Stu Dent ", 18, "20012345 ");
		System.out.println("Student name: " + x.getName());
		System.out.println("Student full details: ");
		x.writeOutput();
	}

    
}
