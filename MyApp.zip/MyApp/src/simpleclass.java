/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author qmahmoo9
 */
public class simpleclass {
    public String forenames;
    public String surename;
    public int age;
    
    public static void main(String[] args) {
        simpleclass p = new simpleclass();
                p.forenames = "paul";
                System.out.println(p.forenames);
                
                   
    }
    
}
