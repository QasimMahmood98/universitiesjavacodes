/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author qmahmoo9
 */
public class person8a {
    public static void main(String[] args) {
        
    }
    private String name;
	private int age;

	public person8a(String n, int a) {
		name = n;
		age = a;
	}
	
	public String getName() {
		return name;
	}
	public int getAge() {
		return age;
	}
	public void writeOutput() {
		System.out.println("Name: " + getName() + " Age: " + getAge());
	}


}
