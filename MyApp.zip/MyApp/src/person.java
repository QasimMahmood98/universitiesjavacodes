/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author qmahmoo9
 */
public class person {
    public String forename;
    public String surename;
    public int age;
    
 public person (String forename, String surename , int age) {
     this.forename = forename;
     this.surename = surename;
     this.age = age;
     
     public person() {
         
     }
 }
 
}
