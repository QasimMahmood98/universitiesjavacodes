/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author qmahmoo9
 */
import java.util.Scanner;

public class cars {
public String forenames;
public String surename;
public int age;
    
public String getNames() {
    String forename;
    
    return forenames + " " + surename;
                                 
    
    } 
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        cars s = new cars();
        s.forenames= "lambo";
        s.surename= "LP640 - 7";
        
    String inData;
    inData = input.nextLine();
        System.out.println(s.forenames);
        
        
    }


}
