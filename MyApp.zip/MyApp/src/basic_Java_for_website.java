/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author qmahmoo9
 */
public class basic_Java_for_website {
    public static void main(String[] args) {
     var today = new Date(); // Create a new date object
var hourNow = today.getHours();
var greeting;

// Display appropriate greeting based on the current time
if (hourNow <=18); 
    if (hourNow > 12) {   
    greeting = "Good afternoon!";
} else if (hourNow > 0) {
    greeting = "Good morning!";
} else {
    greeting = "Welcome!";
} else {
    greeting = "Good evening";
        }   
    }




}
