/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.util.*;

/**
 * so this will link back to 
 * @author qmahmoo9
 */
public class PetRecordDemo {

    public static void main(String[] args) {
        PetRecord usersPet = new PetRecord("Jane Doe");
        System.out.println("My records on your pet are inaccurate.");
        System.out.println("Here is what they currently say:");
        usersPet.writeOutput();

        Scanner keyboard = new Scanner(System.in);
        System.out.println("Please enter the correct pet name:");
        String correctName = keyboard.nextLine();

        System.out.println("Please enter the correct pet age:");
        int correctAge = keyboard.nextInt();

        System.out.println("Please enter the correct pet weight:");
        double correctWeight = keyboard.nextDouble();

        usersPet.setAll(correctName, correctAge, correctWeight);
        System.out.println("My updated records now say:");
        usersPet.writeOutput();
        System.out.println("==================================");

        PetRecord usersPet1 = new PetRecord(correctName, correctAge, correctWeight);

        usersPet1.writeOutput();
    }
}
