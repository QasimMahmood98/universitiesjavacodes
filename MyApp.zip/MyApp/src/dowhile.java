/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author qmahmoo9
 */
public class dowhile {
    public static void main(String args[]) {
int i=200;
do {
System.out.println(i);
i++;
} while (i<=1);
}
}

