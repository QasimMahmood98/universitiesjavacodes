import java.util.Scanner;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *this is a if else statement if it doesn't recongise the word hello it says 
 * string not equal then it will end the programme but if the word says hello
 * then it will say strings are equals
 * @author qmahmoo9
 */
public class IfandElseStatements {
    public static void main (String[] args) {
                Scanner stdin = new Scanner(System.in);
		String inData;
		System.out.println("Enter a word:");
                // here we take user input
		inData = stdin.nextLine();
		String response = "hello";
		
                if (inData.equals(response)) {
                    System.out.println("strings are equal");
		}
		else {
                    System.out.println("strings are no equal");   
		}
		System.out.println("End of program");
}
}




