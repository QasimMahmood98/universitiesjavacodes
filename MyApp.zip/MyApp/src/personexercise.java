/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author qmahmoo9
 */
public class personexercise {
 public String forename;
 public String Surname;
 public int age;
 
    public static void main(String args[]) {
        personexercise p = new personexercise();
        p.forename = "Qasim" ;
        System.out.println(p.forename);
        p.Surname = "Mahmood" ;
        System.out.println(p.Surname);
        p.age = 19;
        System.out.println(p.age);
        
        personexercise p2 = new personexercise();
        p2.forename = "paul" ;
        System.out.println(p2.forename);
        p2.Surname = "trundle" ;
        System.out.println(p2.Surname);
        p2.age = 32;
        System.out.println(p2.age);
        
        personexercise p3 = new personexercise();
        p3.forename = "..." ;
        System.out.println(p3.forename);
        p3.Surname = "..." ;
        System.out.println(p3.Surname);
        //p3.age = ;
        System.out.println(p3.age);
        
    }
      
}
