/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author qmahmoo9
 */
public class exercise4b {
    public static void main(String[] args)  {
        int x = 1;
        double y = 2.5;
        char z = 'A' ;
        boolean w = true;
        String s = "The list of values of my variables is : ";
        String delimiter = ", ";
        System.out.println("Hello and welcome to java programming!");
        System.out.println("s + x + delimiter + y +delimiter + z + delimiter + w delimiter ");
    }
    }

        
