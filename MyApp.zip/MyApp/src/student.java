/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author qmahmoo9
 */
public class student extends person8a
{	
	private String idNumber;

    public student(String n, int a) {
        super(n, a);
    }

	public student(String n, int a, String i) {
		super(n, a);
		idNumber = i;
	}
	
	public void setId(String id) {
		idNumber = id;
	}

	public String getId() {
		return idNumber;
	}

	public void writeOutput() {
		super.writeOutput();
		System.out.println("ID: " + getId());
	}
}

