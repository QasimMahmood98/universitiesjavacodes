/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package crime_database;

import java.sql.*;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author qmahmoo9
 */
public class Database_connector {
    private Connection con;
    private Statement st;
   private ResultSet rs;
     public JTable table = null;
    public Database_connector(){
        try{
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://lamp.scim.brad.ac.uk:3306/qmahmoo9","qmahmoo9","Ip0dinit");
            st = con.createStatement();
            
        }catch(Exception ex){
            System.out.println("Error:" + ex);
        }
    }
    public JTable getTable(){
        String[] names = {"Antisocial behvaiour", "Bugarly", "Voilence and other", "Theft from the person", "Drugs", "Robbery", "shoplifting", "vehicle crime", "possesion of weapon", "public"};
         JTable test = null;
        try{
            
            String query = "select * from crimedata";
            rs = st.executeQuery(query);
            System.out.println("record from databse");
            DefaultTableModel model = new DefaultTableModel();
            model.setColumnIdentifiers(names);
            while (rs.next()){
                Object[] objectArray = new Object[rs.getMetaData().getColumnCount()];
                for (int i =0; i< objectArray.length; i++){
                 objectArray[i] =rs.getObject(i + 1);
                }
                model.addRow(objectArray);
            }
             test = new JTable(model);
        }catch(Exception ex){
            System.out.println(ex);
        }
   return test; 
    }
    public void getData(){
        try{
            String query = "select * from crimedata";
            rs = st.executeQuery(query);
            System.out.println("record from databse");
            DefaultTableModel model = new DefaultTableModel();
            
            while (rs.next()){
                Object[] objectArray = new Object[rs.getMetaData().getColumnCount()];
                for (int i =0; i< objectArray.length; i++){
                 objectArray[i] =rs.getObject(i + 1);
                }
                model.addRow(objectArray);
                
                String longitude= rs.getString("longitude");
                String latitude = rs.getString("latitude");
                String crimeID = rs.getString("crime ID");
                String Month = rs.getString("month");
                String Reportedby =rs.getString("Reported by");
                String FallsWithin = rs.getString("Falls Within");
                String Location =rs.getString("Location");
                String LSOACode =rs.getString("LSOA Code");
                String LSOAName = rs.getString("LSOA Name");
                String CrimeType = rs.getString("Crime Type");
                String Lastoutcomecategory = rs.getString("Last outcome category");
                String Context = rs.getString("Context");
                System.out.println("longitude"+longitude+"latitude"+latitude+"crimeID"+crimeID+"month"+Month+"Reportedby"+Reportedby+"FallsWithin"+FallsWithin+"Location"+Location+"LSOACode"+LSOACode+"LSOAName"+LSOAName+"CrimeType"+CrimeType);
            }
            table = new JTable(model);
        }catch(Exception ex){
            System.out.println(ex);
        }
    }

    private static class Reported {

        public Reported() {
        }
    }

    private static class LSOA {

        public LSOA() {
        }
    }

    private static class Falls {

        public Falls() {
        }
    }

    private static class outcome {

        public outcome() {
        }
    }
    
}

//jatble, filtable, 
