/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
 /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package crime_database;

import static com.sun.xml.internal.fastinfoset.alphabet.BuiltInRestrictedAlphabets.table;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.util.Vector;
import javax.swing.table.DefaultTableModel;
import javax.swing.JTable;
import javax.swing.JScrollPane;

public class GUIhandler {

    String[] items = {"Antisocial behvaiour", "Bugarly", "Voilence and other", "Theft from the person", "Drugs", "Robbery", "shoplifting", "vehicle crime", "possesion of weapon", "public"};
    JComboBox c = new JComboBox(items);
    JButton x = new JButton("print");
    JLabel y = new JLabel("Display Combo Items");
    JScrollPane tableScrollPane = new JScrollPane();
  
    
    private JFrame fr;
    private JPanel P;
    JTable t;
    public GUIhandler() {

      

    }

    public void gui() {
        fr = new JFrame("Crime Data Base");

        fr.setVisible(true);
        fr.setSize(1500, 500);
        fr.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        P = new JPanel();
        P.setBackground(Color.WHITE);

        JLabel label = new JLabel("Longitude");
        label.setPreferredSize(new Dimension(75, 25));
        P.add(label);

        JTextField textField = new JTextField();
        textField.setPreferredSize(new Dimension(200, 20));
        P.add(textField);

        JButton button = new JButton("search");
        button.setPreferredSize(new Dimension(110, 25));
        P.add(button);
        button.addActionListener(c);

        JLabel labeltwo = new JLabel("Latitude");
        labeltwo.setPreferredSize(new Dimension(75, 25));
        P.add(labeltwo);

        JTextField textFieldtwo = new JTextField();
        textFieldtwo.setPreferredSize(new Dimension(200, 20));
        P.add(textFieldtwo);

        JButton buttontwo = new JButton("search");
        buttontwo.setPreferredSize(new Dimension(110, 25));
        P.add(buttontwo);
        buttontwo.addActionListener(c);

        JLabel labelThird = new JLabel("LSOA ");
        labelThird.setPreferredSize(new Dimension(75, 25));
        P.add(labelThird);

        JTextField textFieldThird = new JTextField();
        textFieldThird.setPreferredSize(new Dimension(200, 20));
        P.add(textFieldThird);

        JButton buttonThird = new JButton("search");
        buttonThird.setPreferredSize(new Dimension(110, 25));
        P.add(buttonThird);
        buttonThird.addActionListener(c);
       Database_connector trythis = new Database_connector();
        t = trythis.getTable();
//        tableScrollPane.add(t);
        t.setVisible(true);
        tableScrollPane.setVisible(true);

       
        fr.add(P, BorderLayout.NORTH);
        fr.add(c, BorderLayout.SOUTH);
        fr.add(tableScrollPane, BorderLayout.CENTER);

        fr.revalidate();
        x.addActionListener(new ActionListener() {
            public void actionPerform(ActionEvent e) {
                String s = c.getSelectedItem().toString();
                y.setText(s);
            }
  
   
        
            @Override
            public void actionPerformed(ActionEvent ae) {
                throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }
        });
    }

    public static void main(String[] args) {

        String a;
        a = JOptionPane.showInputDialog("Please enter your name");
        JOptionPane.showMessageDialog(null, "Logged on as " + a);
        Connection con = null;
        Statement st = null;
        ResultSet rs = null;
        String s;
        try {
            Database_connector connect = new Database_connector();
            connect.getData();

           
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "ERROR");
        } finally {
            try {
                st.close();
                rs.close();
                con.close();
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "ERROR CLOSE");
            }
        }
        }
}


/**
 *
 * @author qmahmoo9
 */
